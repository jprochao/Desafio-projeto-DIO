CREATE TABLE adm_feliciano_van ( 
    USUARIO     	CHAR(08) NOT NULL,
    EMAIL       	CHAR(100) NOT NULL,
    PERMISSOES      CHAR(100)
    )
